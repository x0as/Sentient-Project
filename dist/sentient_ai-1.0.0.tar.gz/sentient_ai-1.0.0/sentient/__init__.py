"""
Sentient - AI-powered cybersecurity and automation toolkit
"""

__version__ = "1.0.0"
__author__ = "x0as"
__email__ = "muhammadhuzaifakhalidaziz@gmail.com"
__description__ = "AI-powered cybersecurity and automation toolkit"

from .main import main

__all__ = ["main"]