def capture_packets(interface="eth0", count=10):
    # Placeholder: Real packet capture would use scapy or pyshark and require admin/root
    return f"Captured {count} packets on {interface} (demo only)."

# Example usage:
# print(capture_packets())